# This is a small typer quiz project
---

> ### this is created to practice quiz for exam only
